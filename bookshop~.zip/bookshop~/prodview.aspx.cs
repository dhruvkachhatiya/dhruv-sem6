﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class prodview : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Connect con = new Connect();
        DataTable dt = con.getRow("Select * From product where pro_id ='" + Session["pid"].ToString() + "'");
        lblnm.Text = dt.Rows[0]["pro_name"].ToString();
        Label1.Text = dt.Rows[0]["pro_rate"].ToString();
        TextBox1.Text = dt.Rows[0]["pro_features"].ToString();
       
            Image1.ImageUrl = "prd/"  + dt.Rows[0]["p_image"].ToString();
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Session["mid"] == null)
        {
            Response.Redirect("login.aspx");
        }
        Connect con = new Connect();
        int p = con.getMax("select isnull(MAX(a_id),0)+1 from add_cart");

      
        int qty = int.Parse(txtQty.Text);
        int price = int.Parse(Label1.Text);
        string sq1 = "insert into add_cart values(" + p + ",'" + Session["tid"].ToString() + "','" + Session["mid"].ToString() + "','" + Session["cate"].ToString() + "','" + lblnm.Text + "'," + qty + "," + price + "," + (qty * price) + ")";

   

        con.update(sq1);
        Response.Redirect("detailsview.aspx");
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
}
