﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class creditcard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Connect con = new Connect();
        int p = con.getMax("select isnull(MAX(aid),0)+1 from card");

     
        string sq = "insert into card values("+p+",'" + Session["mid"].ToString() + "','" + Session["tid"].ToString() + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "')";
        con.update(sq);

     
        Response.Write("<script type='text/javascript'>alert('Thanks You buy our products');window.location.href='Default.aspx';</script>");
        
    }
}
