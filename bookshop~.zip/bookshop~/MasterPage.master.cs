﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

public partial class MasterPage : System.Web.UI.MasterPage
{
    static Random random = new Random();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["mid"] == null)
        {
            Label1.Text = "Guest..";
            Session["tid"] = (random.Next(10, 100000)).ToString();
            LinkButton1.Visible = true;
            LinkButton2.Visible = true;
            LinkButton3.Visible = false;

        }
        else
        {
            Label1.Text = Session["mid"].ToString();
            LinkButton1.Visible = false;
            LinkButton2.Visible = false;
            LinkButton3.Visible = true;

        }
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Remove("mid");
        Response.Redirect("default.aspx");
    }
}
