﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class adminnew : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string sq = "select * from admin where admin_id='" + TextBox1.Text + "' and admin_pass='" + TextBox2.Text + "'";

        Connect con = new Connect();

        if (con.check_data(sq))
        {
            Session["uname"] = TextBox1.Text;
            Response.Redirect("adminview.aspx");

        }
        else
        {
            Label1.Text = "Wrong Username or Password";

        }
    }
}